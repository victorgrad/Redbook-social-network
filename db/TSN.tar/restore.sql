--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.0
-- Dumped by pg_dump version 14.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "ToySocialNetwork";
--
-- Name: ToySocialNetwork; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "ToySocialNetwork" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE "ToySocialNetwork" OWNER TO postgres;

\connect "ToySocialNetwork"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: event_participants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event_participants (
    event_id bigint NOT NULL,
    username character varying NOT NULL,
    notification_enabled boolean DEFAULT false,
    notification_seen boolean DEFAULT false
);


ALTER TABLE public.event_participants OWNER TO postgres;

--
-- Name: events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events (
    id bigint NOT NULL,
    name character varying NOT NULL,
    date timestamp without time zone,
    description character varying,
    location character varying
);


ALTER TABLE public.events OWNER TO postgres;

--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_id_seq OWNER TO postgres;

--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.events_id_seq OWNED BY public.events.id;


--
-- Name: friendship_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.friendship_requests (
    first_user character varying NOT NULL,
    second_user character varying NOT NULL,
    status character varying,
    date timestamp without time zone,
    notification_seen boolean DEFAULT false
);


ALTER TABLE public.friendship_requests OWNER TO postgres;

--
-- Name: friendships; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.friendships (
    first_user character varying NOT NULL,
    second_user character varying NOT NULL,
    begin_date date
);


ALTER TABLE public.friendships OWNER TO postgres;

--
-- Name: message_recipients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.message_recipients (
    message bigint NOT NULL,
    recipient character varying NOT NULL,
    notification_seen boolean DEFAULT false
);


ALTER TABLE public.message_recipients OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id bigint NOT NULL,
    date timestamp without time zone,
    "from" character varying NOT NULL,
    text character varying,
    original_message bigint
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.messages_id_seq OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    username character varying NOT NULL,
    first_name character varying,
    last_name character varying,
    pass character varying NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Data for Name: event_participants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.event_participants (event_id, username, notification_enabled, notification_seen) FROM stdin;
\.
COPY public.event_participants (event_id, username, notification_enabled, notification_seen) FROM '$$PATH$$/3366.dat';

--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.events (id, name, date, description, location) FROM stdin;
\.
COPY public.events (id, name, date, description, location) FROM '$$PATH$$/3365.dat';

--
-- Data for Name: friendship_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.friendship_requests (first_user, second_user, status, date, notification_seen) FROM stdin;
\.
COPY public.friendship_requests (first_user, second_user, status, date, notification_seen) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: friendships; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.friendships (first_user, second_user, begin_date) FROM stdin;
\.
COPY public.friendships (first_user, second_user, begin_date) FROM '$$PATH$$/3359.dat';

--
-- Data for Name: message_recipients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.message_recipients (message, recipient, notification_seen) FROM stdin;
\.
COPY public.message_recipients (message, recipient, notification_seen) FROM '$$PATH$$/3360.dat';

--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, date, "from", text, original_message) FROM stdin;
\.
COPY public.messages (id, date, "from", text, original_message) FROM '$$PATH$$/3361.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (username, first_name, last_name, pass) FROM stdin;
\.
COPY public.users (username, first_name, last_name, pass) FROM '$$PATH$$/3362.dat';

--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.events_id_seq', 13, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.messages_id_seq', 47, true);


--
-- Name: event_participants event_participants_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_participants
    ADD CONSTRAINT event_participants_pk PRIMARY KEY (event_id, username);


--
-- Name: events events_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pk PRIMARY KEY (id);


--
-- Name: friendship_requests friendship_request_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friendship_requests
    ADD CONSTRAINT friendship_request_pk PRIMARY KEY (first_user, second_user);


--
-- Name: friendships friendships_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT friendships_pk PRIMARY KEY (first_user, second_user);


--
-- Name: message_recipients message_recipients_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_recipients
    ADD CONSTRAINT message_recipients_pk PRIMARY KEY (message, recipient);


--
-- Name: messages messages_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pk PRIMARY KEY (id);


--
-- Name: users users_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pk PRIMARY KEY (username);


--
-- Name: event_participants event_participants_events_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_participants
    ADD CONSTRAINT event_participants_events_id_fk FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: event_participants event_participants_users_username_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_participants
    ADD CONSTRAINT event_participants_users_username_fk FOREIGN KEY (username) REFERENCES public.users(username) ON DELETE CASCADE;


--
-- Name: friendship_requests friendship_request_users_username_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friendship_requests
    ADD CONSTRAINT friendship_request_users_username_fk FOREIGN KEY (first_user) REFERENCES public.users(username) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: friendship_requests friendship_request_users_username_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friendship_requests
    ADD CONSTRAINT friendship_request_users_username_fk_2 FOREIGN KEY (second_user) REFERENCES public.users(username) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: friendships friendships_users_username_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT friendships_users_username_fk FOREIGN KEY (first_user) REFERENCES public.users(username) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: friendships friendships_users_username_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT friendships_users_username_fk_2 FOREIGN KEY (second_user) REFERENCES public.users(username) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: message_recipients message_recipients_messages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_recipients
    ADD CONSTRAINT message_recipients_messages_id_fk FOREIGN KEY (message) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: message_recipients message_recipients_users_username_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_recipients
    ADD CONSTRAINT message_recipients_users_username_fk FOREIGN KEY (recipient) REFERENCES public.users(username) ON DELETE CASCADE;


--
-- Name: messages messages_messages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_messages_id_fk FOREIGN KEY (original_message) REFERENCES public.messages(id) ON DELETE SET NULL;


--
-- Name: messages messages_users_username_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_users_username_fk FOREIGN KEY ("from") REFERENCES public.users(username) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

